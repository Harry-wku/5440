import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import joblib
import torchvision.transforms as transforms
from sklearn.model_selection import train_test_split


# Define Separable Convolution for Xception-based architecture
class SeparableConv2D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False):
        super(SeparableConv2D, self).__init__()
        self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, stride=stride, padding=padding,
                                   groups=in_channels, bias=bias)
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.depthwise(x)
        x = self.pointwise(x)
        return x


# Define Xception Model
class Xception(nn.Module):
    def __init__(self, in_channels, num_classes):
        super(Xception, self).__init__()
        self.entry_flow = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            SeparableConv2D(32, 64, 3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        # Middle flow
        self.middle_flow = nn.Sequential(
            SeparableConv2D(64, 128, 3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.Dropout(0.3),
            SeparableConv2D(128, 256, 3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.Dropout(0.3),
            SeparableConv2D(256, 512, 3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.Dropout(0.3)
        )

        # Exit flow
        self.exit_flow = nn.Sequential(
            SeparableConv2D(512, 1024, 3, padding=1),
            nn.BatchNorm2d(1024),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Dropout(0.3)
        )

        self.fc = nn.Linear(1024, num_classes)

    def forward(self, x):
        x = self.entry_flow(x)
        x = self.middle_flow(x)
        x = self.exit_flow(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


def evaluate_model():
    # Load the data
    '''
    example_data_2.pkl      Test Accuracy: 85.02%
    example_data.pkl        Test Accuracy: 4.03%
    example_data_6.pkl      Test Accuracy: 0.00%
    example_data_6_2.pkl    Test Accuracy: 0.00%
    example_data_a_1d1.pkl  Test Accuracy: 0.00%
    example_data_2_1.pkl    Test Accuracy: 4.03%
    '''
    data_file = "example_data_2.pkl"#example_data_2.pkl
    x_data, y_data = joblib.load(data_file)

    # Data preprocessing
    transform = transforms.Compose([
        transforms.Resize((45, 30)),
        transforms.ToTensor(),
        transforms.Normalize((0.5,), (0.5,))
    ])

    x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=42)

    # Convert to tensors
    x_test_tensor = torch.tensor(x_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.long)

    batch_size = 256
    test_dataset = TensorDataset(x_test_tensor, y_test_tensor)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=4, pin_memory=True)

    # Load the model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = Xception(in_channels=1, num_classes=9).to(device)

    # Load the trained model weights
    model.load_state_dict(torch.load('xception_model_optimized_1.pth'))#xception_model_optimized_1.pth
    model.eval()

    # Evaluate the model
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    test_accuracy = 100 * correct / total
    print(f"Test Accuracy: {test_accuracy:.2f}%")

if __name__ == '__main__':
    evaluate_model()
