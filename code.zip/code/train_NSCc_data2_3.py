import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
import joblib
from tqdm import tqdm
import torch.nn.functional as F
import torchvision.transforms as transforms
from multiprocessing import freeze_support
from torch.cuda.amp import autocast, GradScaler  # 引入混合精度训练

def main():
    # ========== 第一步：加载example_data_2.pkl数据并划分训练集和测试集 ==========
    data_file = "example_data_2.pkl"
    x_data, y_data = joblib.load(data_file)

    # 数据预处理 (转为张量和数据增强)
    transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(10),
        transforms.RandomResizedCrop(45),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
        transforms.ToTensor(),  # 转换为张量
        transforms.Normalize((0.5,), (0.5,))  # 正则化
    ])

    # 划分数据集为训练集 (80%) 和测试集 (20%)
    x_train, x_test, y_train, y_test = train_test_split(x_data, y_data, test_size=0.2, random_state=42)

    # 转换为张量
    x_train_tensor = torch.tensor(x_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.long)
    x_test_tensor = torch.tensor(x_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.long)

    # 增大批次大小到 256，充分利用显存
    batch_size = 256

    # 创建训练集和测试集的数据加载器，使用 num_workers=8 提高数据加载效率，并启用 pin_memory
    train_dataset = TensorDataset(x_train_tensor, y_train_tensor)
    test_dataset = TensorDataset(x_test_tensor, y_test_tensor)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=8, pin_memory=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=8, pin_memory=True)

    # ========== 第二步：定义改进后的Xception网络 ==========
    class SeparableConv2D(nn.Module):
        def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False):
            super(SeparableConv2D, self).__init__()
            self.depthwise = nn.Conv2d(in_channels, in_channels, kernel_size=kernel_size, stride=stride, padding=padding, groups=in_channels, bias=bias)
            self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=bias)

        def forward(self, x):
            x = self.depthwise(x)
            x = self.pointwise(x)
            return x

    class Xception(nn.Module):
        def __init__(self, in_channels, num_classes):
            super(Xception, self).__init__()
            self.entry_flow = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, stride=2, padding=1, bias=False),
                nn.BatchNorm2d(32),
                nn.ReLU(),
                SeparableConv2D(32, 64, 3, padding=1),
                nn.BatchNorm2d(64),
                nn.ReLU(),
                nn.Dropout(0.3)  # 添加Dropout层防止过拟合
            )

            # Middle flow (multiple separable conv blocks)
            self.middle_flow = nn.Sequential(
                SeparableConv2D(64, 128, 3, padding=1),
                nn.BatchNorm2d(128),
                nn.ReLU(),
                nn.Dropout(0.3),  # 添加Dropout层
                SeparableConv2D(128, 256, 3, padding=1),
                nn.BatchNorm2d(256),
                nn.ReLU(),
                nn.Dropout(0.3),  # 添加Dropout层
                SeparableConv2D(256, 512, 3, padding=1),
                nn.BatchNorm2d(512),
                nn.ReLU(),
                nn.Dropout(0.3)  # 添加Dropout层
            )

            # Exit flow
            self.exit_flow = nn.Sequential(
                SeparableConv2D(512, 1024, 3, padding=1),
                nn.BatchNorm2d(1024),
                nn.ReLU(),
                nn.AdaptiveAvgPool2d((1, 1)),  # 全局池化
                nn.Dropout(0.3)  # 添加Dropout层
            )

            # 全连接层
            self.fc = nn.Linear(1024, num_classes)

        def forward(self, x):
            x = self.entry_flow(x)
            x = self.middle_flow(x)
            x = self.exit_flow(x)
            x = torch.flatten(x, 1)
            x = self.fc(x)
            return x

    # ========== 第三步：训练模型并进行测试 ==========
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # 定义模型并迁移到GPU
    model = Xception(in_channels=1, num_classes=9).to(device)

    # 混合精度缩放器
    scaler = GradScaler()

    # 定义损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=0.0005, weight_decay=1e-4)

    # 使用 CosineAnnealingLR 学习率调度器
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=10)

    # 训练模型
    num_epochs = 100
    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        # 训练阶段
        for inputs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs}"):
            inputs, labels = inputs.to(device), labels.to(device)

            optimizer.zero_grad()

            # 启用混合精度训练
            with autocast():
                outputs = model(inputs)
                loss = criterion(outputs, labels)

            # 反向传播和优化
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        accuracy = 100 * correct / total
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss/total:.4f}, Accuracy: {accuracy:.2f}%')

        # 每个 epoch 后更新学习率
        scheduler.step()

    # ========== 第四步：评估模型性能 ==========
    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    test_accuracy = 100 * correct / total
    print(f"测试集上的准确率: {test_accuracy:.2f}%")

    # ========== 第五步：保存模型 ==========
    torch.save(model.state_dict(), 'trained_model_data2/xception_model_gpu_optimized.pt')
    print("模型训练完成并已保存为 xception_model_gpu_optimized.pt")

if __name__ == '__main__':
    freeze_support()
    main()
